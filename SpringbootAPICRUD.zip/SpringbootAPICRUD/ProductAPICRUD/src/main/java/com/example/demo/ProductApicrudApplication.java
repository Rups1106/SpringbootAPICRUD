package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductApicrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductApicrudApplication.class, args);
		System.out.println("Successfully completed");
		
	}

}
