package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.model.Product;
import com.example.repository.ProductRepository;

@RestController
@RequestMapping("/api")
public class ProductController {
    
	@Autowired
	ProductRepository productRepository;
	
	@PostMapping("/Products")
	 public String createNewProduct(@RequestBody Product product) {
        productRepository.save(product); // Fixed the typo
        return "Product Created in database";
}
	@GetMapping("/Products/{id}")
	public Product getProductById(@PathVariable Long id) {
	    return productRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
	}
	@PutMapping("/Products/{id}")
	public String updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct) {
	    Product existingProduct = productRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
	    // Update the existing product's fields with the new values
	    existingProduct.setName(updatedProduct.getName());
	    existingProduct.setPrice(updatedProduct.getPrice());
	    existingProduct.setPrice(updatedProduct.getPrice());
	    productRepository.save(existingProduct);
	    return "Product updated successfully";
	}

	@DeleteMapping("/Products/{id}")
	public String deleteProduct(@PathVariable Long id) {
	    Product existingProduct = productRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
	    productRepository.delete(existingProduct);
	    return "Product deleted successfully";
	}

}