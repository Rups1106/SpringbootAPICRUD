//package com.example.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.model.Category;
//import com.example.repository.CategoryRepository;
//
//@RestController
//@RequestMapping("/api")
//public class CategoryController {
//
//	@Autowired
//	CategoryRepository categoryRepository;
//	
//	@PostMapping("/categories")
//	
//	public String createNewCategory(@RequestBody Category category) {
//	 categoryRepository).save(category);
//		return"Categories Created in database";
//		
//	}
//}
package com.example.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Category;
import com.example.repository.CategoryRepository;

@RestController
@RequestMapping("/api")
public class CategoryController {

    @Autowired
    CategoryRepository categoryRepository;

    @PostMapping("/categories")
    public String createNewCategory(@RequestBody Category category) {
        categoryRepository.save(category); // Fixed the typo
        return "Category Created in database";
        
        }
    @GetMapping("/categories")
    public List<Category> getAllCategories() {
        return (List<Category>) categoryRepository.findAll(); // Returns all categories
    }
    @PutMapping("/categories/{id}")
    public ResponseEntity<String> updateCategory(@PathVariable Long id, @RequestBody Category updatedCategory) {
        Optional<Category> existingCategory = categoryRepository.findById(id);
        if (existingCategory.isPresent()) {
            Category category = existingCategory.get();
            category.setName(updatedCategory.getName()); // Update name
            category.setDescription(updatedCategory.getDescription()); // Update description
            categoryRepository.save(category); // Save updated category
            return ResponseEntity.ok("Category updated successfully");
        } else {
            return ResponseEntity.notFound().build(); // Category not found
        }
    }

    // DELETE method to delete a category by ID
    @DeleteMapping("/categories/{id}")
    public ResponseEntity<String> deleteCategory(@PathVariable Long id) {
        if (categoryRepository.existsById(id)) {
            categoryRepository.deleteById(id); // Deletes category by ID
            return ResponseEntity.ok("Category deleted successfully");
        } else {
            return ResponseEntity.notFound().build(); // Category not found
        }
    }
    }


