package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoryApicrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CategoryApicrudApplication.class, args);
		System.out.println("Succesfully completed");
		
	}

}